
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'alvannwaorim',
  applicationName: 'serverless-todo-app',
  appUid: 'ryRtwsSqBRZGdx4vZY',
  orgUid: '35047959-6f5e-40aa-b3d9-53579d0eb586',
  deploymentUid: 'f84cb2bd-d8bd-443b-b9a2-d22550e8276d',
  serviceName: 'serverless-todo-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.6.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-todo-app-dev-GenerateUploadUrl', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/generateUploadUrl.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}