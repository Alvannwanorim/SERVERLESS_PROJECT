
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'alvannwaorim',
  applicationName: 'serverless-todo-app',
  appUid: 'ryRtwsSqBRZGdx4vZY',
  orgUid: '35047959-6f5e-40aa-b3d9-53579d0eb586',
  deploymentUid: '8ab6bcd0-aa66-4080-99f4-8294010564ab',
  serviceName: 'serverless-todo-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.6.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-todo-app-dev-GetTodos', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/getTodos.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}